# newsserver
智慧北京APP服务端

学习该课程的同学可以把HMApi.java类中BASE_URL改一下，就不用开启tomcat服务器了

public final static String BASE_URL ="https://raw.githubusercontent.com/shingkit/newsserver/master";
 
